//
//  UserupdatesCollectionViewCell.swift
//  Zade
//
//  Created by Parth Bhojak on 12/07/19.
//  Copyright © 2019 Parth Bhojak. All rights reserved.
//

import UIKit

class UserupdatesCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var uploadedImage: UIImageView!
    
    
    @IBOutlet weak var usersTextpost: UILabel!
    
}
