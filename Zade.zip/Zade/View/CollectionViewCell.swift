//
//  CollectionViewCell.swift
//  Zade
//
//  Created by Parth Bhojak on 15/07/19.
//  Copyright © 2019 Parth Bhojak. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var collectionImage: UIImageView!
    
    @IBOutlet weak var collectionName: UILabel!
    
    @IBOutlet weak var collectionPrice: UILabel!
    
    
    @IBOutlet weak var likeCollect: UIButton!
    
    @IBAction func CollectionLike(_ sender: UIButton) {
        
        
    }
    
    
}
