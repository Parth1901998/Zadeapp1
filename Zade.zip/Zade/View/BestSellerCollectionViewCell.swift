//
//  BestSellerCollectionViewCell.swift
//  Zade
//
//  Created by Parth Bhojak on 15/07/19.
//  Copyright © 2019 Parth Bhojak. All rights reserved.
//

import UIKit

class BestSellerCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var sellerImages: UIImageView!
    
    @IBOutlet weak var sellerName: UILabel!
    
    
}
