//
//  SideProductCollectionViewCell.swift
//  Zade
//
//  Created by Parth Bhojak on 17/07/19.
//  Copyright © 2019 Parth Bhojak. All rights reserved.
//

import UIKit

class SideProductCollectionViewCell: UICollectionViewCell {
    

    
    @IBOutlet weak var proImage: UIImageView!
    
    
    @IBOutlet weak var proName: UILabel!
    
    @IBOutlet weak var Pricevalue: UILabel!
    
    
    @IBOutlet weak var LikeProduct: UIButton!
    
    
}
