//
//  CommentViewController.swift
//  Zade
//
//  Created by Parth Bhojak on 18/07/19.
//  Copyright © 2019 Parth Bhojak. All rights reserved.
//

import UIKit

class CommentViewController: UIViewController {
    
    
    @IBOutlet weak var cmtButton: UITextField!
    
  

    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    
    
    @IBAction func commetPressed(_ sender: UIButton) {
        
      
    }
    
}
