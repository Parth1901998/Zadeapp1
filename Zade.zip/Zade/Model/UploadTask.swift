//
//  UploadTask.swift
//  Zade
//
//  Created by Parth Bhojak on 15/07/19.
//  Copyright © 2019 Parth Bhojak. All rights reserved.
//

import Foundation
import UIKit

class UploadTask
{
var post : String = ""
var imagename : String = ""
var image : UIImage?
var useruuid : String = ""
var photourl : String = ""
var like : Bool  = false
var count : String = ""
var lasttiming  = ""
var userimage : UIImage?
var usernames : String = ""
    
    
    
}
