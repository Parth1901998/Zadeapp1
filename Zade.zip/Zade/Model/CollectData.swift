//
//  CollectData.swift
//  Zade
//
//  Created by Parth Bhojak on 15/07/19.
//  Copyright © 2019 Parth Bhojak. All rights reserved.
//

import Foundation
import UIKit

class NewArriveModel {
    
    var newarrriveImage : UIImage?
    var newarriveName : String = ""
    var newarrivePrice : String = ""
    var likeproduct : Bool = false

}


class CollectModel {
    var collectImage : UIImage?
    var collectName : String = ""
    var collectPrice :String = ""
    var likeproduct : Bool = false
}

class BestSellerModel {
    var bestImage : UIImage?
    var bestName : String = ""
   
}
