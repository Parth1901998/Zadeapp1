//
//  SidebarModel.swift
//  Zade
//
//  Created by Parth Bhojak on 17/07/19.
//  Copyright © 2019 Parth Bhojak. All rights reserved.
//

import Foundation
import UIKit

class MenModel
{
    var mbname : String = ""
    var mbprice : String = ""
    var mbimage : UIImage?
    
}

class WomenMode
{
    var wbname : String = ""
    var wbprice : String = ""
    var wbimage : UIImage?
}
