//
//  UserTotalPostModel.swift
//  Zade
//
//  Created by Parth Bhojak on 15/07/19.
//  Copyright © 2019 Parth Bhojak. All rights reserved.
//

import Foundation
import UIKit

class UserTotalPostModel
{
    var allPhotos : UIImage?
    var userposttext : String = ""
    var like : UIButton?
    var likevalue : String = ""
    var lasttiming : String = ""
}
