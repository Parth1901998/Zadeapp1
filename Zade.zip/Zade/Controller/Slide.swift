//
//  Slide.swift
//  Zade
//
//  Created by Parth Bhojak on 08/07/19.
//  Copyright © 2019 Parth Bhojak. All rights reserved.
//

import UIKit

class Slide: UIView {
    
    

    @IBOutlet weak var slideImages: UIImageView!
    
    
    @IBOutlet weak var detailLabel: UILabel!
    
    
    @IBOutlet weak var descriptionLabel: UILabel!
    
    
    @IBOutlet weak var skipPressed: UIButton!
    
    
    @IBAction func skipPresedButton(_ sender: UIButton) {
        
        
        
    }
    
    
    
}
